package com.commentapp.spring.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.commentapp.spring.model.Comments;

public interface CommentJPARepo extends JpaRepository<Comments, Long> {

	@Query(value="select u.email,c.comment from users u join comments c on u.id=c.uid_fk;",nativeQuery=true)
	public List<Comments> showAllUsersComments();
}

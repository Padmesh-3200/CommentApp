package com.commentapp.spring.service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.stereotype.Component;

@Component
public class Encryption {

	public String encryptMD5(String password) throws NoSuchAlgorithmException {

		MessageDigest md = MessageDigest.getInstance("MD5");
		byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));

		StringBuilder spass = null;
		spass = new StringBuilder();
		for (byte v : hash) {
			spass.append(String.format("%02x", v));
		}
		// System.out.println(spass.toString());
		return spass.toString();
	}

	public static String EncrpytPassword(String str) {

		StringBuilder sb = new StringBuilder();
		char[] ch = str.toCharArray();

		for (char c : ch) {
			c += 77;

			sb.append(c);
		}

		return sb.toString();

	}

	public static String DecrpytPassword(String str) {

		StringBuilder sb = new StringBuilder();

		char[] ch = str.toCharArray();

		for (char c : ch) {
			c -= 77;

			sb.append(c);
		}
		return sb.toString();

	}

}

package com.commentapp.spring.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.commentapp.spring.model.Users;

public interface UserJPARepo extends JpaRepository<Users, Long> {
	
	
	@Query(value="select id from users where email= ? AND password= ?",nativeQuery=true)
	public List<Integer> validateUserLogin(@Param("email") String email , @Param("password") String password);

	@Transactional
	@Modifying
	@Query(value="UPDATE users SET login_status=? WHERE id= ?",nativeQuery=true) 
	public void updateLoginStatus(@Param("status") boolean status,@Param("id")int id);
	
	@Transactional
	@Modifying
	@Query(value="UPDATE users SET login_status=false WHERE id= ?",nativeQuery=true) 
	public void updateSignoutStatus(@Param("id")int id);

	@Query(value="select password from users where email= ? AND secret_code= ?",nativeQuery=true)
	public String getForgottenPassword(@Param("email")String email,@Param("password") String secretCode);
    
	@Query(value="select id from users where email= ?",nativeQuery=true)
	public Integer checkRegisteredEmail(@Param("email") String email);
	
}

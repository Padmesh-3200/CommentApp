package com.commentapp.spring.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.commentapp.spring.repo.UserRepo;

public class tests {
	

	
	
	public static void main(String[] str) {

		
	}

	public static String EncrpytPassword(String str) {

		StringBuilder sb = new StringBuilder();
		char[] ch = str.toCharArray();

		for (char c : ch) {
			c += 7;
			System.out.print(c);
			sb.append(c);
		}
		System.out.println();
		return sb.toString();

	}

	public static String DecrpytPassword(String str) {

		StringBuilder sb = new StringBuilder();
		char[] ch = str.toCharArray();

		for (char c : ch) {
			c -= 7;
			System.out.print(c);
			sb.append(c);
		}
		System.out.println();
		return sb.toString();

	}
}

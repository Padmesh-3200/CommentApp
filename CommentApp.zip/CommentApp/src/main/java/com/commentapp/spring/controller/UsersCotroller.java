package com.commentapp.spring.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.commentapp.spring.model.Comments;
import com.commentapp.spring.model.UserAndComments;
import com.commentapp.spring.model.Users;
import com.commentapp.spring.repo.UserRepo;
import com.commentapp.spring.service.Encryption;

@Controller
public class UsersCotroller {

	@Autowired
	private UserRepo repo;

	@Autowired
	private Encryption en;

	@GetMapping("")
	public String viewHomePage(Model model) {
		model.addAttribute("user", new Users());

		return "signin";
	}

	@GetMapping("signup")
	public String showSignup(Model model) {
		model.addAttribute("user", new Users());
		return "signup";
	}

	@GetMapping("signin")
	public String showSignin(Model model) {
		model.addAttribute("user", new Users());

		return "signin";
	}

	@GetMapping("forget_password")
	public String forgetPassword(Model model) {

		model.addAttribute("user", new Users());

		return "forgetPassword";
	}

	@GetMapping("get_password")
	public String forgetPassword_withoutNavigatingFromForgetPassword(Model model) {
		model.addAttribute("user", new Users());

		return "signin";

	}

	@PostMapping("get_password")
	public ModelAndView forgetPassword(Users user) {

		ModelAndView mv = new ModelAndView();
		if (user == null) {
			mv.setViewName("signin");
			return mv;
		}

		String password = repo.getForgottenPassword(user.getEmail(), user.getSecretCode());
		

		if (password != null) {
			password = en.DecrpytPassword(password);
			System.out.println("password :"+password);
			mv.addObject("password", "Your password is " + password);
			mv.addObject("user", new Users());
			mv.setViewName("forgetPassword");
			return mv;
		}

		mv.addObject("password", "User does not exist!");
		mv.addObject("user", new Users());
		mv.setViewName("forgetPassword");
		return mv;
	}

	@GetMapping("commentApp")
	public String showCommentApp(Model model, HttpSession session) {
		String status = (String) session.getAttribute("loginStatus");
		if (status != null && status.equalsIgnoreCase("success")) {
			// getting the list of comments from db and setting in modelview
			return "commentApp";
		}

		model.addAttribute("user", new Users());
		return "signin";

	}

	@PostMapping("success_registeration")
	public String successRegistration(Users user,Model model) {

		String password = new String();

		System.out.println("register_check :"+user.getEmail());
		
		boolean flag = repo.checkRegisteredEmail(user.getEmail());
		
		if(flag) {
			model.addAttribute("check","You are already registered!");
			model.addAttribute("user", new Users());
			return "signup";
		}
		
		password = en.EncrpytPassword(user.getPassword());

		System.out.println("encrypted pass :" + password);
		user.setLoginStatus(false);
		user.setPassword(password);
		repo.save(user);
		return "success_registration";
		
		
		
	}

	@PostMapping("login")
	public ModelAndView Login(Users user, HttpSession session) {

		ModelAndView mv = new ModelAndView();

		System.out.println("user original pass :" + user.getPassword());
		String password = null;
		System.out.println();

		password = en.EncrpytPassword(user.getPassword());

		int id = repo.validateLogin(user.getEmail(), password);

		List<UserAndComments> uc = repo.showAllUsersComments(false);

		uc.forEach((e) -> System.out.println(e.getEmail() + "  " + e.getComment()));

		if (id != 0) {

			repo.updateLoginStatus(id, true);
			session.setAttribute("loginId", id);
			session.setAttribute("loginStatus", "success");
			mv.addObject("comment", new Comments());
			mv.addObject("listComments", uc);
			mv.setViewName("commentApp");
			return mv;
		}

		mv.setViewName("signin");
		mv.addObject("error", "Invalid username or password");
		mv.addObject("user", new Users());
		return mv;
	}

	@PostMapping("comment_submitted")
	public ModelAndView submitComment(Comments comment, HttpSession session) {

		ModelAndView mv = new ModelAndView();
		int id = (int) session.getAttribute("loginId");
		repo.submitComment(id, comment.getComment());

		// String status = (String) session.getAttribute("loginStatus");
		// if (status != null && status.equalsIgnoreCase("success")) {

		List<UserAndComments> uc = repo.showAllUsersComments(false);
		mv.addObject("comment", new Comments());
		mv.addObject("listComments", uc);
		mv.setViewName("commentApp");
		return mv;

	}

	@GetMapping("filter")
	public ModelAndView filterComments(HttpSession session) {

		ModelAndView mv = new ModelAndView();
		// int id = (int) session.getAttribute("loginId");

		// String status = (String) session.getAttribute("loginStatus");
		// if (status != null && status.equalsIgnoreCase("success")) {

		List<UserAndComments> uc = repo.showAllUsersComments(true);
		uc.forEach((e) -> System.out.println("filter  :" + e.getEmail() + "  " + e.getComment()));
		mv.addObject("comment", new Comments());
		mv.addObject("listComments", uc);
		mv.setViewName("commentApp");
		return mv;
	}

	@GetMapping("signout")
	public String signOut(Model model, HttpSession session) {

		int id = (int) session.getAttribute("loginId");
		repo.updateLoginStatus(id, false);
		session.invalidate();
		model.addAttribute("user", new Users());

		return "signin";
	}

}

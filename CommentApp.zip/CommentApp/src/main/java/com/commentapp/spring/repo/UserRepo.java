package com.commentapp.spring.repo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.commentapp.spring.model.UserAndComments;
import com.commentapp.spring.model.Users;
import com.commentapp.spring.service.UtilDAO;

@Repository
public class UserRepo {

	@Autowired
	private UserJPARepo userJpaRepo;

	public void save(Users user) {
		userJpaRepo.save(user);
	}

	public int validateLogin(String email, String password) {

		List<Integer> ids = userJpaRepo.validateUserLogin(email, password);

		return ids.size() == 1 ? ids.get(0) : 0;

	}

	public void updateLoginStatus(int id, boolean status) {

		userJpaRepo.updateLoginStatus(status, id);

	}

	public String getForgottenPassword(String email, String secretCode) {

		String password = userJpaRepo.getForgottenPassword(email, secretCode);

		return password;
	}

	public boolean checkRegisteredEmail(String email) {

		return userJpaRepo.checkRegisteredEmail(email) == null ? false : true;
	}

	public void submitComment(int id, String comment) {

		Connection con = null;
		con = UtilDAO.getDBConnection();

		try {

			String sql = "insert into comments(comment,uid_fk) values('" + comment + "'," + id + ")";
			Statement stmt = con.createStatement();
			stmt.execute(sql);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public List<UserAndComments> showAllUsersComments(boolean filterFlag) {
		Connection con = null;
		con = UtilDAO.getDBConnection();
		List<UserAndComments> userCommentList = new ArrayList<UserAndComments>();
		UserAndComments userComment = null;
		try {

			String sql = "select u.email,c.comment from users u join comments c on u.id=c.uid_fk";
			if (filterFlag) {
				sql += " AND u.login_status=true";
			}
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				userComment = new UserAndComments();
				userComment.setEmail(rs.getString("u.email")); ///////////////////// DOUBT
				userComment.setComment(rs.getString("c.comment"));
				userCommentList.add(userComment);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userCommentList;
	}

}

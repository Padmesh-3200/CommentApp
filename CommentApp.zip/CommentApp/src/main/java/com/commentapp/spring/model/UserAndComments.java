package com.commentapp.spring.model;


public class UserAndComments {
	
	private String email;
	
	private String comment;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

}
